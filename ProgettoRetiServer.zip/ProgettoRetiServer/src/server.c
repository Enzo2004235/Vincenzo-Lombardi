#include <time.h>
#if defined WIN32
#include <winsock.h>
#else
printf("Compiling for Unix/Linux.\n");
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#define closesocket close
#endif
#include <stdio.h>
#include "protocol.h"

// Function to generate numeric passwords
void generate_numeric(char *password, int length);
// Function to generate alphabetic passwords
void generate_alpha(char *password, int length);
// Function to generate mixed passwords (letters and digits)
void generate_mixed(char *password, int length);
// Function to generate secure passwords (letters, digits, special characters)
void generate_secure(char *password, int length);

// Function to handle errors by printing messages
void errorhandler(const char *errorMessage) {
    perror(errorMessage);
}

// Function to clean up resources for Windows systems
void clearwinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

int main() {
#if defined WIN32
    // Initialize Winsock for Windows
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        errorhandler("Error at WSAStartup()");
        return -1;
    }
#endif

    // Create the server socket
    int server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server_socket < 0) {
        errorhandler("Socket creation failed.");
        clearwinsock();
        return -1;
    }

    // Configure the server address
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(DEFAULT_IP); // Use default server IP
    server_addr.sin_port = htons(DEFAULT_PORT);          // Use default server port

    // Bind the server socket to the specified address and port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        errorhandler("Bind failed.");
        closesocket(server_socket);
        clearwinsock();
        return -1;
    }

    // Start listening for incoming connections
    if (listen(server_socket, QLEN) < 0) {
        errorhandler("Listen failed.");
        closesocket(server_socket);
        clearwinsock();
        return -1;
    }

    printf("Server ready on %s:%d\n", inet_ntoa(server_addr.sin_addr), ntohs(server_addr.sin_port));
    srand((unsigned int)time(NULL)); // Seed the random number generator

    struct sockaddr_in client_addr;
    int client_socket;
    int client_len = sizeof(client_addr);

    // Main server loop
    while (1) {
        printf("Waiting for a new connection...\n");

        // Accept a new connection from a client
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            errorhandler("Accept failed.");
            continue; // Continue accepting other clients
        }

        printf("New connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Handle client requests
        request req;
        while (1) {
            int bytes_received = recv(client_socket, (char *)&req, sizeof(req), 0);
            if (bytes_received <= 0) {
                printf("Client disconnected.\n");
                break;
            }

            // Handle disconnect request
            if (req.request_type == 'q') {
                printf("Client requested to quit.\n");
                break;
            }

            // Validate password length
            if (req.length < MIN_PASSWORD_LENGTH || req.length > MAX_PASSWORD_LENGTH) {
                printf("Invalid password length requested.\n");
                continue;
            }

            // Generate the password based on the request type
            switch (req.request_type) {
                case 'n': generate_numeric(req.password, req.length); break;
                case 'a': generate_alpha(req.password, req.length); break;
                case 'm': generate_mixed(req.password, req.length); break;
                case 's': generate_secure(req.password, req.length); break;
                default:
                    printf("Invalid request type received.\n");
                    continue;
            }

            // Send the generated password to the client
            if (send(client_socket, (const char *)&req, sizeof(req), 0) <= 0) {
                errorhandler("Failed to send response to client.");
                break;
            }
        }

        // Close the connection with the client
        closesocket(client_socket);
        printf("Connection closed with client.\n");
    }

    // Close the server socket and clean up
    closesocket(server_socket);
    clearwinsock();
    return 0;
}

// Generate a numeric password (digits only)
void generate_numeric(char *password, int length) {
    for (int i = 0; i < length; ++i)
        password[i] = '0' + (rand() % 10);
    password[length] = '\0';
}

// Generate an alphabetic password (lowercase letters only)
void generate_alpha(char *password, int length) {
    for (int i = 0; i < length; ++i)
        password[i] = 'a' + (rand() % 26);
    password[length] = '\0';
}

// Generate a mixed password (letters and digits)
void generate_mixed(char *password, int length) {
    for (int i = 0; i < length; ++i) {
        if (rand() % 2)
            password[i] = 'a' + (rand() % 26);
        else
            password[i] = '0' + (rand() % 10);
    }
    password[length] = '\0';
}

// Generate a secure password (letters, digits, special characters)
void generate_secure(char *password, int length) {
    const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    int charset_size = sizeof(charset) - 1;
    for (int i = 0; i < length; ++i)
        password[i] = charset[rand() % charset_size];
    password[length] = '\0';
}
