#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define DEFAULT_PORT 60000
#define DEFAULT_IP "127.0.0.1"
#define BUFFER_SIZE 64
#define MAX_PASSWORD_LENGTH 32
#define MIN_PASSWORD_LENGTH 6
#define QLEN 5

typedef struct {
    char request_type; // 'n', 'a', 'm', 's', or 'q'
    int length;        // password length
    char password[MAX_PASSWORD_LENGTH + 1]; // generated password
} request;

#endif /* PROTOCOL_H_ */
