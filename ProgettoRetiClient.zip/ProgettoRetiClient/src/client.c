#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#define closesocket close
#endif
#include <time.h>
#include <stdio.h>
#include "protocol.h"

void errorhandler(const char *errorMessage) {
    perror(errorMessage);
}

void clearwinsock() {
#if defined WIN32w
    WSACleanup();
#endif
}

int main() {
#if defined WIN32
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        errorhandler("Error at WSAStartup()");
        return -1;
    }
#endif

    // Create the client socket
    int client_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (client_socket < 0) {
        errorhandler("Socket creation failed.");
        clearwinsock();
        return -1;
    }

    // Set server address and port
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(DEFAULT_IP);
    server_addr.sin_port = htons(DEFAULT_PORT);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        errorhandler("Connect failed");
        closesocket(client_socket);
        clearwinsock();
        return -1;
    }

    printf("Connected to the server.\n");

    // Initialize the request structure
    request req;
    while (1) {
        // Get the user input
        printf("Enter request (n/a/m/s <length> or q to quit): ");
        char input[BUFFER_SIZE];
        fgets(input, BUFFER_SIZE, stdin);

        // Parse the input
        if (sscanf(input, "%c %d", &req.request_type, &req.length) < 1) {
            printf("Invalid input. Try again.\n");
            continue;
        }

        // Check if the user wants to quit
        if (req.request_type == 'q') {
            printf("Exiting client...\n");
            send(client_socket, (const char *)&req, sizeof(req), 0); // Notify the server
            break;
        }

        // Validate password length
        if (req.length < MIN_PASSWORD_LENGTH || req.length > MAX_PASSWORD_LENGTH) {
            printf("Password length must be between %d and %d.\n", MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
            continue;
        }

        // Send the request to the server
        if (send(client_socket,  (const char *)&req, sizeof(req), 0) <= 0) {
            errorhandler("Failed to send the request.");
            break;
        }

        // Receive the response from the server
        if (recv(client_socket,  (char *)&req, sizeof(req), 0) <= 0) {
            errorhandler("Failed to receive response from the server.");
            break;
        }

        // Print the generated password
        printf("Generated password: %s\n", req.password);
    }

    // Close the socket and cleanup
    closesocket(client_socket);
    clearwinsock();
    return 0;
}
